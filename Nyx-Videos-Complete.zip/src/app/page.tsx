"use client";

import { useEffect, useState } from "react";
import Link from "next/link";

interface ProjectSummary {
  id: string;
  name: string;
  style: string;
  description?: string;
  updatedAt: string;
  clipCount: number;
  characterCount: number;
}

const STYLE_LABELS: Record<string, string> = {
  realistic_ad: "Realistic Ad",
  artist_trailer: "Artist Trailer",
  music_video: "Music Video",
  cinematic_movie: "Cinematic Movie",
  cartoon: "Cartoon",
  anime: "Anime",
};

export default function HomePage() {
  const [projects, setProjects] = useState<ProjectSummary[]>([]);
  const [loading, setLoading] = useState(true);
  const [showCreate, setShowCreate] = useState(false);
  const [name, setName] = useState("");
  const [style, setStyle] = useState("artist_trailer");
  const [description, setDescription] = useState("");
  const [creating, setCreating] = useState(false);

  useEffect(() => {
    fetchProjects();
  }, []);

  async function fetchProjects() {
    try {
      const res = await fetch("/api/projects");
      const data = await res.json();
      setProjects(data.projects || []);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  }

  async function handleCreate(e: React.FormEvent) {
    e.preventDefault();
    if (!name.trim()) return;
    setCreating(true);
    try {
      const res = await fetch("/api/projects", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name, style, description }),
      });
      const data = await res.json();
      if (data.project) {
        window.location.href = `/projects/${data.project.id}`;
      }
    } catch (err) {
      console.error(err);
    } finally {
      setCreating(false);
    }
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-10">
      <div className="flex items-end justify-between mb-10">
        <div>
          <h1 className="text-3xl font-bold tracking-tight mb-2">Projects</h1>
          <p className="text-[#8b8b9e] max-w-xl">
            Create a project, lock faces and assets, then generate continuous
            15-second segments that remember everything that came before.
          </p>
        </div>
        <button
          onClick={() => setShowCreate(true)}
          className="px-5 py-2.5 rounded-lg bg-continuum-600 hover:bg-continuum-500 text-white font-medium transition-colors shadow-lg shadow-continuum-900/40"
        >
          New Project
        </button>
      </div>

      {showCreate && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-[#0f0f16] border border-[#1c1c28] rounded-2xl w-full max-w-md p-6 shadow-2xl">
            <h2 className="text-xl font-semibold mb-5">Create Project</h2>
            <form onSubmit={handleCreate} className="space-y-4">
              <div>
                <label className="block text-sm text-[#8b8b9e] mb-1.5">
                  Project Name
                </label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="My Brother's Trailer"
                  className="w-full px-3 py-2.5 rounded-lg bg-[#16161f] border border-[#2a2a3a] focus:border-continuum-500 focus:outline-none transition-colors"
                  autoFocus
                />
              </div>
              <div>
                <label className="block text-sm text-[#8b8b9e] mb-1.5">
                  Style
                </label>
                <select
                  value={style}
                  onChange={(e) => setStyle(e.target.value)}
                  className="w-full px-3 py-2.5 rounded-lg bg-[#16161f] border border-[#2a2a3a] focus:border-continuum-500 focus:outline-none"
                >
                  {Object.entries(STYLE_LABELS).map(([value, label]) => (
                    <option key={value} value={value}>
                      {label}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm text-[#8b8b9e] mb-1.5">
                  Description (optional)
                </label>
                <textarea
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  rows={2}
                  placeholder="Promo trailer for new artist..."
                  className="w-full px-3 py-2.5 rounded-lg bg-[#16161f] border border-[#2a2a3a] focus:border-continuum-500 focus:outline-none resize-none"
                />
              </div>
              <div className="flex gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setShowCreate(false)}
                  className="flex-1 py-2.5 rounded-lg border border-[#2a2a3a] hover:bg-[#1a1a24] transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={creating || !name.trim()}
                  className="flex-1 py-2.5 rounded-lg bg-continuum-600 hover:bg-continuum-500 disabled:opacity-50 text-white font-medium transition-colors"
                >
                  {creating ? "Creating..." : "Create"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {loading ? (
        <div className="text-[#8b8b9e] py-20 text-center">Loading projects...</div>
      ) : projects.length === 0 ? (
        <div className="border border-dashed border-[#2a2a3a] rounded-2xl py-20 text-center">
          <p className="text-[#8b8b9e] mb-4">No projects yet</p>
          <button
            onClick={() => setShowCreate(true)}
            className="text-continuum-400 hover:text-continuum-300 font-medium"
          >
            Create your first project →
          </button>
        </div>
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {projects.map((p) => (
            <Link
              key={p.id}
              href={`/projects/${p.id}`}
              className="group block p-5 rounded-xl bg-[#0f0f16] border border-[#1c1c28] hover:border-continuum-700/60 transition-all hover:shadow-lg hover:shadow-continuum-950/30"
            >
              <div className="flex items-start justify-between mb-3">
                <h3 className="font-semibold text-lg group-hover:text-continuum-300 transition-colors">
                  {p.name}
                </h3>
                <span className="text-xs px-2 py-0.5 rounded-full bg-[#16161f] text-[#8b8b9e] border border-[#2a2a3a]">
                  {STYLE_LABELS[p.style] || p.style}
                </span>
              </div>
              {p.description && (
                <p className="text-sm text-[#8b8b9e] mb-4 line-clamp-2">
                  {p.description}
                </p>
              )}
              <div className="flex items-center gap-4 text-xs text-[#6b6b7b]">
                <span>{p.clipCount} clips</span>
                <span>{p.characterCount} characters</span>
                <span className="ml-auto">
                  {new Date(p.updatedAt).toLocaleDateString()}
                </span>
              </div>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
