import { NextRequest, NextResponse } from "next/server";
import { addAsset, updateCharacter, getProject } from "@/lib/db/store";
import type { AssetType } from "@/types";

export async function POST(req: NextRequest) {
  try {
    const formData = await req.formData();
    const projectId = formData.get("projectId") as string;
    const type = formData.get("type") as AssetType;
    const characterId = formData.get("characterId") as string | null;
    const file = formData.get("file") as File | null;

    if (!projectId || !type || !file) {
      return NextResponse.json(
        { error: "projectId, type, and file are required" },
        { status: 400 }
      );
    }

    const buffer = Buffer.from(await file.arrayBuffer());
    const asset = await addAsset(
      projectId,
      type,
      file.name,
      buffer,
      file.type || "application/octet-stream"
    );

    // If this is a face reference and a character is specified, attach it
    if (characterId && (type === "face_reference" || type === "full_body_reference")) {
      const project = await getProject(projectId);
      if (project) {
        const character = project.characters.find((c) => c.id === characterId);
        if (character) {
          const key =
            type === "face_reference" ? "faceReferences" : "fullBodyReferences";
          const existing = character[key] || [];
          await updateCharacter(projectId, characterId, {
            [key]: [...existing, asset.id],
          });
        }
      }
    }

    return NextResponse.json({ asset });
  } catch (err: any) {
    console.error("Asset upload error:", err);
    return NextResponse.json(
      { error: err.message || "Upload failed" },
      { status: 500 }
    );
  }
}
