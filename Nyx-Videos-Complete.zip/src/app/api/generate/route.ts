import { NextRequest, NextResponse } from "next/server";
import { generateNextSegment } from "@/lib/video/generate";
import { addClip, getProject } from "@/lib/db/store";

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const {
      projectId,
      script,
      clipId,
      duration,
      strengthenFaceLock,
      provider,
    } = body;

    if (!projectId || !script) {
      return NextResponse.json(
        { error: "projectId and script are required" },
        { status: 400 }
      );
    }

    const project = await getProject(projectId);
    if (!project) {
      return NextResponse.json({ error: "Project not found" }, { status: 404 });
    }

    // Create a new clip if none provided
    let targetClipId = clipId;
    if (!targetClipId) {
      const newClip = await addClip(projectId, script);
      targetClipId = newClip.id;
    }

    const result = await generateNextSegment({
      projectId,
      clipId: targetClipId,
      script,
      duration: duration || 15,
      strengthenFaceLock: !!strengthenFaceLock,
      provider,
    });

    return NextResponse.json(result);
  } catch (err: any) {
    console.error("Generation error:", err);
    return NextResponse.json(
      { error: err.message || "Generation failed" },
      { status: 500 }
    );
  }
}
