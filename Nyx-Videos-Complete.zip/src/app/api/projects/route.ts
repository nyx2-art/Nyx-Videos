import { NextRequest, NextResponse } from "next/server";
import {
  createProject,
  listProjects,
  getProject,
} from "@/lib/db/store";
import type { ProjectStyle } from "@/types";

export async function GET() {
  try {
    const projects = await listProjects();
    const summaries = projects.map((p) => ({
      id: p.id,
      name: p.name,
      style: p.style,
      description: p.description,
      updatedAt: p.updatedAt,
      clipCount: p.clips.length,
      characterCount: p.characters.length,
    }));
    return NextResponse.json({ projects: summaries });
  } catch (err: any) {
    return NextResponse.json(
      { error: err.message || "Failed to list projects" },
      { status: 500 }
    );
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { name, style, description } = body;

    if (!name || typeof name !== "string") {
      return NextResponse.json(
        { error: "Name is required" },
        { status: 400 }
      );
    }

    const validStyles: ProjectStyle[] = [
      "realistic_ad",
      "artist_trailer",
      "music_video",
      "cinematic_movie",
      "cartoon",
      "anime",
    ];

    const projectStyle = validStyles.includes(style) ? style : "artist_trailer";

    const project = await createProject(name.trim(), projectStyle, description);

    return NextResponse.json({ project });
  } catch (err: any) {
    return NextResponse.json(
      { error: err.message || "Failed to create project" },
      { status: 500 }
    );
  }
}
