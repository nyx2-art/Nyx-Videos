/**
 * Continuum – Video Generation Provider Abstraction
 *
 * All real model calls go through this interface.
 * Implementations for Kling, Seedance, Veo, Runway, HeyGen live in sibling files.
 * For the starter we provide a high-quality mock that still exercises the full pipeline.
 */

import type {
  GenerationRequest,
  GenerationResult,
  ContinuityPackage,
  Project,
} from "@/types";

export interface VideoProvider {
  name: string;
  supportsExtend: boolean;
  supportsMultiReference: boolean;
  supportsNativeAudio: boolean;

  generate(
    project: Project,
    continuity: ContinuityPackage,
    request: GenerationRequest
  ): Promise<GenerationResult>;
}

/**
 * Registry of available providers.
 * Real implementations will be added as you plug in API keys.
 */
const providers: Record<string, VideoProvider> = {};

export function registerProvider(provider: VideoProvider) {
  providers[provider.name] = provider;
}

export function getProvider(name: string): VideoProvider | null {
  return providers[name] || null;
}

export function listProviders(): string[] {
  return Object.keys(providers);
}
