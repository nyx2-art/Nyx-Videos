/**
 * Nyx Videos – Provider configuration
 * All real API keys come from environment variables only.
 * Never hard-code keys in source files.
 */

export function getKlingKey(): string | undefined {
  return process.env.KLING_API_KEY;
}

export function getHeyGenKey(): string | undefined {
  return process.env.HEYGEN_API_KEY;
}

export function getElevenLabsKey(): string | undefined {
  return process.env.ELEVENLABS_API_KEY;
}

export function getGoogleKey(): string | undefined {
  return process.env.GOOGLE_API_KEY;
}

export function hasAnyRealProvider(): boolean {
  return !!(
    getKlingKey() ||
    getHeyGenKey() ||
    getElevenLabsKey() ||
    getGoogleKey()
  );
}
