/**
 * Continuum – Mock Video Provider
 * Exercises the full continuity + last-frame pipeline without requiring paid API keys.
 * Useful for development and for verifying the hardest technical parts work.
 *
 * In production you replace this with real Kling / Seedance / Veo / HeyGen clients.
 */

import type {
  GenerationRequest,
  GenerationResult,
  ContinuityPackage,
  Project,
} from "@/types";
import type { VideoProvider } from "./base";
import { registerProvider } from "./base";
import { extractLastFrame, imageToVideo } from "@/lib/video/ffmpeg";
import path from "path";
import fs from "fs/promises";
import { randomUUID } from "crypto";

export const mockProvider: VideoProvider = {
  name: "mock",
  supportsExtend: true,
  supportsMultiReference: true,
  supportsNativeAudio: false,

  async generate(
    project: Project,
    continuity: ContinuityPackage,
    request: GenerationRequest
  ): Promise<GenerationResult> {
    try {
      const outputDir = path.join(
        process.cwd(),
        "public",
        "uploads",
        project.id,
        "clips"
      );
      await fs.mkdir(outputDir, { recursive: true });

      const clipId = request.clipId;
      const videoFilename = `${clipId}.mp4`;
      const videoPath = path.join(outputDir, videoFilename);
      const publicVideoPath = `/uploads/${project.id}/clips/${videoFilename}`;

      // If we have a last frame, turn it into a short "continuation" video
      // so the pipeline is fully exercised. In real life this would be a model call.
      if (continuity.lastFramePath) {
        // Convert absolute or public path to real filesystem path
        const realLastFrame = continuity.lastFramePath.startsWith("/")
          ? path.join(process.cwd(), "public", continuity.lastFramePath)
          : continuity.lastFramePath;

        await imageToVideo(realLastFrame, videoPath, request.duration ?? 12);
      } else if (continuity.referenceImagePaths.length > 0) {
        // Use first reference image as starting point
        const ref = continuity.referenceImagePaths[0];
        const realRef = ref.startsWith("/")
          ? path.join(process.cwd(), "public", ref)
          : ref;
        await imageToVideo(realRef, videoPath, request.duration ?? 12);
      } else {
        // Absolute fallback – create a simple colored video via ffmpeg
        // (still better than nothing for pipeline testing)
        await createPlaceholderVideo(videoPath, request.duration ?? 12);
      }

      // Always extract last frame so the next segment can continue
      const lastFrameFilename = `${clipId}_lastframe.jpg`;
      const lastFramePath = path.join(outputDir, lastFrameFilename);
      const publicLastFrame = `/uploads/${project.id}/clips/${lastFrameFilename}`;

      await extractLastFrame(videoPath, lastFramePath);

      return {
        success: true,
        videoPath: publicVideoPath,
        lastFramePath: publicLastFrame,
        duration: request.duration ?? 12,
        provider: "mock",
      };
    } catch (err: any) {
      return {
        success: false,
        error: err.message || "Mock generation failed",
      };
    }
  },
};

async function createPlaceholderVideo(
  outputPath: string,
  duration: number
): Promise<void> {
  const { execFile } = await import("child_process");
  const { promisify } = await import("util");
  const execFileAsync = promisify(execFile);

  // Generate a simple dark cinematic placeholder
  await execFileAsync("ffmpeg", [
    "-y",
    "-f",
    "lavfi",
    "-i",
    `color=c=0x0a0a12:s=1280x720:d=${duration}`,
    "-vf",
    "drawtext=text='Continuum Mock Segment':fontcolor=white:fontsize=36:x=(w-text_w)/2:y=(h-text_h)/2",
    "-c:v",
    "libx264",
    "-pix_fmt",
    "yuv420p",
    "-t",
    String(duration),
    outputPath,
  ]);
}

// Auto-register
registerProvider(mockProvider);
