/**
 * Continuum – FFmpeg helpers
 * Last-frame extraction, basic stitching, audio ducking preparation.
 * Requires ffmpeg installed on the system.
 */

import { execFile } from "child_process";
import { promisify } from "util";
import path from "path";
import fs from "fs/promises";

const execFileAsync = promisify(execFile);

/**
 * Extract the very last frame of a video as a high-quality JPEG.
 * This frame becomes the continuity anchor for the next generation.
 */
export async function extractLastFrame(
  videoPath: string,
  outputPath: string
): Promise<string> {
  // Ensure output directory exists
  await fs.mkdir(path.dirname(outputPath), { recursive: true });

  // Get duration first so we can seek near the end
  const duration = await getVideoDuration(videoPath);
  const seekTime = Math.max(0, duration - 0.15); // slightly before end to avoid black frames

  await execFileAsync("ffmpeg", [
    "-y",
    "-ss",
    seekTime.toFixed(3),
    "-i",
    videoPath,
    "-frames:v",
    "1",
    "-q:v",
    "2", // high quality JPEG
    outputPath,
  ]);

  // Verify the file was created
  await fs.access(outputPath);
  return outputPath;
}

/**
 * Get duration of a video in seconds.
 */
export async function getVideoDuration(videoPath: string): Promise<number> {
  const { stdout } = await execFileAsync("ffprobe", [
    "-v",
    "error",
    "-show_entries",
    "format=duration",
    "-of",
    "default=noprint_wrappers=1:nokey=1",
    videoPath,
  ]);

  const duration = parseFloat(stdout.trim());
  if (isNaN(duration)) {
    throw new Error(`Could not read duration of ${videoPath}`);
  }
  return duration;
}

/**
 * Simple concatenation of multiple clips into one sequence.
 * Uses the concat demuxer for speed and quality preservation.
 */
export async function concatenateClips(
  clipPaths: string[],
  outputPath: string
): Promise<string> {
  if (clipPaths.length === 0) {
    throw new Error("No clips to concatenate");
  }
  if (clipPaths.length === 1) {
    await fs.copyFile(clipPaths[0], outputPath);
    return outputPath;
  }

  await fs.mkdir(path.dirname(outputPath), { recursive: true });

  // Create a temporary concat list file
  const listPath = outputPath + ".concat.txt";
  const listContent = clipPaths
    .map((p) => `file '${path.resolve(p).replace(/'/g, "'\\''")}'`)
    .join("\n");

  await fs.writeFile(listPath, listContent);

  try {
    await execFileAsync("ffmpeg", [
      "-y",
      "-f",
      "concat",
      "-safe",
      "0",
      "-i",
      listPath,
      "-c",
      "copy", // stream copy when possible
      outputPath,
    ]);
  } finally {
    // Clean up list file
    await fs.unlink(listPath).catch(() => {});
  }

  return outputPath;
}

/**
 * Apply simple side-chain style music ducking.
 * When voice is present, reduce music volume.
 * This is a basic version – for production you would use a proper compressor.
 *
 * @param voicePath  – the voice-over or dialogue track
 * @param musicPath  – background music
 * @param outputPath – final mixed audio
 * @param duckAmount – how much to lower music (0.0–1.0), default 0.35
 */
export async function applyMusicDucking(
  voicePath: string,
  musicPath: string,
  outputPath: string,
  duckAmount = 0.35
): Promise<string> {
  await fs.mkdir(path.dirname(outputPath), { recursive: true });

  // Using sidechaincompress filter
  // voice is the sidechain source, music is the main
  const filter = `[1:a]asplit=2[sc][mix];[0:a][sc]sidechaincompress=threshold=0.08:ratio=6:attack=50:release=300:level_sc=0.8[ducked];[ducked][mix]amix=inputs=2:duration=longest:dropout_transition=0.5,volume=1.0`;

  await execFileAsync("ffmpeg", [
    "-y",
    "-i",
    musicPath,
    "-i",
    voicePath,
    "-filter_complex",
    filter,
    "-c:a",
    "aac",
    "-b:a",
    "192k",
    outputPath,
  ]);

  return outputPath;
}

/**
 * Mux a video with a new audio track (replace or mix).
 */
export async function replaceAudio(
  videoPath: string,
  audioPath: string,
  outputPath: string
): Promise<string> {
  await fs.mkdir(path.dirname(outputPath), { recursive: true });

  await execFileAsync("ffmpeg", [
    "-y",
    "-i",
    videoPath,
    "-i",
    audioPath,
    "-c:v",
    "copy",
    "-c:a",
    "aac",
    "-map",
    "0:v:0",
    "-map",
    "1:a:0",
    "-shortest",
    outputPath,
  ]);

  return outputPath;
}

/**
 * Create a short silent video of a still image (useful for testing continuity).
 */
export async function imageToVideo(
  imagePath: string,
  outputPath: string,
  durationSeconds = 2
): Promise<string> {
  await fs.mkdir(path.dirname(outputPath), { recursive: true });

  await execFileAsync("ffmpeg", [
    "-y",
    "-loop",
    "1",
    "-i",
    imagePath,
    "-c:v",
    "libx264",
    "-t",
    String(durationSeconds),
    "-pix_fmt",
    "yuv420p",
    "-vf",
    "scale=1280:720",
    outputPath,
  ]);

  return outputPath;
}
