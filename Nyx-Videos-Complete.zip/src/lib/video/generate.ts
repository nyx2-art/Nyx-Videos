/**
 * Continuum – Generation Orchestrator
 * This is the high-level service the API routes call.
 * It owns the full flow: continuity package → provider call → finalize last frame → update clip.
 */

import type {
  GenerationRequest,
  GenerationResult,
  Project,
  Clip,
} from "@/types";
import { buildContinuityPackage, finalizeClipAfterGeneration } from "@/lib/continuity/engine";
import { getProvider } from "@/lib/providers/base";
import "@/lib/providers/mock"; // ensure mock is registered
import {
  getProject,
  updateClip,
  saveProject,
} from "@/lib/db/store";
import path from "path";

export async function generateNextSegment(
  request: GenerationRequest
): Promise<{ project: Project; clip: Clip; result: GenerationResult }> {
  const project = await getProject(request.projectId);
  if (!project) {
    throw new Error("Project not found");
  }

  // Make sure the clip exists
  let clip = project.clips.find((c) => c.id === request.clipId);
  if (!clip) {
    throw new Error("Clip not found");
  }

  // Mark as generating
  clip = await updateClip(project.id, clip.id, {
    status: "generating",
    script: request.script,
  });

  try {
    // 1. Build the full continuity package (the hard part)
    const continuity = await buildContinuityPackage(project, request);

    // 2. Choose provider
    const providerName = continuity.recommendedProvider;
    const provider = getProvider(providerName) || getProvider("mock");
    if (!provider) {
      throw new Error("No video provider available");
    }

    // 3. Call the model
    const result = await provider.generate(project, continuity, request);

    if (!result.success || !result.videoPath) {
      await updateClip(project.id, clip.id, {
        status: "failed",
        error: result.error || "Generation failed",
      });
      return {
        project: (await getProject(project.id))!,
        clip: (await getProject(project.id))!.clips.find((c) => c.id === clip.id)!,
        result,
      };
    }

    // 4. Finalize – ensure last frame exists
    let lastFramePath = result.lastFramePath;
    if (result.videoPath && !lastFramePath) {
      try {
        const realVideoPath = result.videoPath.startsWith("/")
          ? path.join(process.cwd(), "public", result.videoPath)
          : result.videoPath;

        const finalized = await finalizeClipAfterGeneration(clip, realVideoPath);
        lastFramePath = finalized.lastFramePath;
      } catch (err) {
        console.warn("Last frame extraction failed after generation:", err);
      }
    }

    // 5. Update clip with results
    const updatedClip = await updateClip(project.id, clip.id, {
      status: "ready",
      videoPath: result.videoPath,
      lastFramePath: lastFramePath || result.lastFramePath,
      finalPrompt: continuity.finalPrompt,
      provider: result.provider as any,
      duration: result.duration,
      generationParams: continuity.generationParams,
      error: undefined,
    });

    const updatedProject = (await getProject(project.id))!;

    return {
      project: updatedProject,
      clip: updatedClip,
      result: {
        ...result,
        lastFramePath: lastFramePath || result.lastFramePath,
      },
    };
  } catch (err: any) {
    await updateClip(project.id, clip.id, {
      status: "failed",
      error: err.message || "Unexpected error during generation",
    });
    throw err;
  }
}
