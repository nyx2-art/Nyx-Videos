/**
 * Continuum – Voice Cloning & Audio Helpers
 *
 * Placeholder for real voice providers (ElevenLabs, PlayHT, Cartesia, etc.).
 * The asset system already accepts voice_sample uploads.
 * When a character has a voiceCloneId, dialogue lines can be synthesized in that voice.
 */

import type { Character, Asset } from "@/types";

export interface VoiceSynthesisRequest {
  text: string;
  voiceCloneId: string;
  language?: string; // e.g. "en", "lg" for Luganda when supported
  stability?: number;
  style?: number;
}

export interface VoiceSynthesisResult {
  success: boolean;
  audioPath?: string;
  duration?: number;
  error?: string;
}

/**
 * In production this calls ElevenLabs / PlayHT / etc.
 * For now it returns a clear "not configured" result so the rest of the pipeline stays clean.
 */
export async function synthesizeVoice(
  request: VoiceSynthesisRequest
): Promise<VoiceSynthesisResult> {
  // TODO: Plug in real provider
  // Example:
  // const client = new ElevenLabsClient({ apiKey: process.env.ELEVENLABS_API_KEY });
  // const audio = await client.textToSpeech.convert(request.voiceCloneId, { text: request.text, ... });

  return {
    success: false,
    error:
      "Voice synthesis provider not yet configured. Upload voice samples and connect ElevenLabs / PlayHT / Cartesia in src/lib/audio/voice.ts",
  };
}

/**
 * Create a voice clone from one or more sample assets.
 * Returns a provider-specific voice ID that can be stored on the Character.
 */
export async function createVoiceClone(
  character: Character,
  sampleAssets: Asset[],
  name?: string
): Promise<{ voiceCloneId?: string; error?: string }> {
  if (sampleAssets.length === 0) {
    return { error: "At least one voice sample is required" };
  }

  // TODO: Real implementation
  // Upload samples to the voice provider and return the resulting voice ID.

  return {
    error:
      "Voice cloning provider not yet configured. Implement in src/lib/audio/voice.ts",
  };
}

/**
 * Helper: detect whether a language is likely to need external TTS
 * (most current video models still struggle with natural Luganda etc.)
 */
export function needsExternalTTS(language: string): boolean {
  const strongNative = ["en", "zh", "ja", "ko", "es", "fr", "de", "pt"];
  return !strongNative.includes(language.toLowerCase().slice(0, 2));
}
