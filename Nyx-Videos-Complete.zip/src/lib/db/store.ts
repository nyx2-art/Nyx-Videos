/**
 * Continuum – Simple file-based project store
 * Easy to replace with Supabase / Postgres later.
 * All project state (characters, assets, clips, continuity anchors) lives here.
 */

import fs from "fs/promises";
import path from "path";
import { randomUUID } from "crypto";
import type {
  Project,
  Character,
  Asset,
  Clip,
  ProjectStyle,
  AssetType,
  ClipStatus,
} from "@/types";

const DATA_DIR = path.join(process.cwd(), "data");
const PROJECTS_DIR = path.join(DATA_DIR, "projects");
const UPLOADS_DIR = path.join(process.cwd(), "public", "uploads");

async function ensureDirs() {
  await fs.mkdir(PROJECTS_DIR, { recursive: true });
  await fs.mkdir(UPLOADS_DIR, { recursive: true });
}

function projectPath(id: string) {
  return path.join(PROJECTS_DIR, `${id}.json`);
}

export async function createProject(
  name: string,
  style: ProjectStyle,
  description?: string
): Promise<Project> {
  await ensureDirs();
  const id = randomUUID();
  const now = new Date().toISOString();

  const project: Project = {
    id,
    name,
    style,
    description,
    characters: [],
    assets: [],
    clips: [],
    styleLocks: {
      aspectRatio: style === "music_video" || style === "artist_trailer" ? "16:9" : "16:9",
    },
    createdAt: now,
    updatedAt: now,
  };

  await fs.writeFile(projectPath(id), JSON.stringify(project, null, 2));
  return project;
}

export async function getProject(id: string): Promise<Project | null> {
  try {
    const raw = await fs.readFile(projectPath(id), "utf-8");
    return JSON.parse(raw) as Project;
  } catch {
    return null;
  }
}

export async function saveProject(project: Project): Promise<Project> {
  project.updatedAt = new Date().toISOString();
  await fs.writeFile(projectPath(project.id), JSON.stringify(project, null, 2));
  return project;
}

export async function listProjects(): Promise<Project[]> {
  await ensureDirs();
  const files = await fs.readdir(PROJECTS_DIR);
  const projects: Project[] = [];

  for (const file of files) {
    if (!file.endsWith(".json")) continue;
    try {
      const raw = await fs.readFile(path.join(PROJECTS_DIR, file), "utf-8");
      projects.push(JSON.parse(raw));
    } catch {
      // skip corrupted
    }
  }

  return projects.sort(
    (a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime()
  );
}

export async function deleteProject(id: string): Promise<void> {
  try {
    await fs.unlink(projectPath(id));
  } catch {
    // ignore
  }
}

// ─────────────────────────────────────────────
// Characters
// ─────────────────────────────────────────────

export async function addCharacter(
  projectId: string,
  name: string,
  appearanceLock?: string
): Promise<Character> {
  const project = await getProject(projectId);
  if (!project) throw new Error("Project not found");

  const character: Character = {
    id: randomUUID(),
    projectId,
    name,
    faceReferences: [],
    fullBodyReferences: [],
    appearanceLock,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };

  project.characters.push(character);
  await saveProject(project);
  return character;
}

export async function updateCharacter(
  projectId: string,
  characterId: string,
  updates: Partial<Character>
): Promise<Character> {
  const project = await getProject(projectId);
  if (!project) throw new Error("Project not found");

  const idx = project.characters.findIndex((c) => c.id === characterId);
  if (idx === -1) throw new Error("Character not found");

  project.characters[idx] = {
    ...project.characters[idx],
    ...updates,
    updatedAt: new Date().toISOString(),
  };

  await saveProject(project);
  return project.characters[idx];
}

// ─────────────────────────────────────────────
// Assets
// ─────────────────────────────────────────────

export async function addAsset(
  projectId: string,
  type: AssetType,
  filename: string,
  buffer: Buffer,
  mimeType: string,
  meta?: Record<string, any>
): Promise<Asset> {
  const project = await getProject(projectId);
  if (!project) throw new Error("Project not found");

  const id = randomUUID();
  const ext = path.extname(filename) || guessExt(mimeType);
  const storedName = `${id}${ext}`;
  const projectUploadDir = path.join(UPLOADS_DIR, projectId);
  await fs.mkdir(projectUploadDir, { recursive: true });

  const fullPath = path.join(projectUploadDir, storedName);
  await fs.writeFile(fullPath, buffer);

  // Public relative path for serving
  const publicPath = `/uploads/${projectId}/${storedName}`;

  const asset: Asset = {
    id,
    projectId,
    type,
    filename,
    path: publicPath,
    mimeType,
    size: buffer.length,
    meta,
    createdAt: new Date().toISOString(),
  };

  // If it's a voice sample, try to get duration later if needed
  project.assets.push(asset);
  await saveProject(project);
  return asset;
}

function guessExt(mime: string): string {
  if (mime.includes("jpeg") || mime.includes("jpg")) return ".jpg";
  if (mime.includes("png")) return ".png";
  if (mime.includes("webp")) return ".webp";
  if (mime.includes("mp3")) return ".mp3";
  if (mime.includes("wav")) return ".wav";
  if (mime.includes("mp4")) return ".mp4";
  if (mime.includes("webm")) return ".webm";
  return "";
}

// ─────────────────────────────────────────────
// Clips
// ─────────────────────────────────────────────

export async function addClip(
  projectId: string,
  script: string,
  index?: number
): Promise<Clip> {
  const project = await getProject(projectId);
  if (!project) throw new Error("Project not found");

  const nextIndex =
    typeof index === "number"
      ? index
      : project.clips.length > 0
        ? Math.max(...project.clips.map((c) => c.index)) + 1
        : 0;

  const clip: Clip = {
    id: randomUUID(),
    projectId,
    index: nextIndex,
    script,
    status: "pending",
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };

  project.clips.push(clip);
  await saveProject(project);
  return clip;
}

export async function updateClip(
  projectId: string,
  clipId: string,
  updates: Partial<Clip>
): Promise<Clip> {
  const project = await getProject(projectId);
  if (!project) throw new Error("Project not found");

  const idx = project.clips.findIndex((c) => c.id === clipId);
  if (idx === -1) throw new Error("Clip not found");

  project.clips[idx] = {
    ...project.clips[idx],
    ...updates,
    updatedAt: new Date().toISOString(),
  };

  await saveProject(project);
  return project.clips[idx];
}

export async function approveClipInStore(
  projectId: string,
  clipId: string
): Promise<Project> {
  const project = await getProject(projectId);
  if (!project) throw new Error("Project not found");

  const { approveClip } = await import("@/lib/continuity/engine");
  const updated = approveClip(project, clipId);
  await saveProject(updated);
  return updated;
}
