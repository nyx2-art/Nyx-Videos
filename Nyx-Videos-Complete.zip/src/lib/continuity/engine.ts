/**
 * Continuum – Continuity Engine
 *
 * This is the heart of the app.
 * Responsibility:
 * 1. Build a rich ContinuityContext from project state
 * 2. Extract last frame from previous approved clip
 * 3. Inject identity locks (faces) and style locks
 * 4. Produce a final generation-ready prompt that forces continuation
 * 5. Prepare reference images / last-frame for the video provider
 */

import type {
  Project,
  Clip,
  Character,
  ContinuityContext,
  GenerationRequest,
  ProjectStyle,
} from "@/types";
import { buildPromptFromTemplate } from "@/lib/prompts/builder";
import { extractLastFrame } from "@/lib/video/ffmpeg";
import path from "path";
import fs from "fs/promises";

export interface ContinuityPackage {
  context: ContinuityContext;
  finalPrompt: string;
  negativePrompt: string;
  /** Paths to images that must be sent as references to the model */
  referenceImagePaths: string[];
  /** Last frame path (if exists) – critical for chaining */
  lastFramePath?: string;
  /** Recommended provider based on style + needs */
  recommendedProvider: string;
  /** Extra generation params */
  generationParams: Record<string, any>;
}

/**
 * Build the full continuity package for the next segment.
 * This is called every time the user generates a new 15s part.
 */
export async function buildContinuityPackage(
  project: Project,
  request: GenerationRequest
): Promise<ContinuityPackage> {
  const previousClip = getLastApprovedClip(project);
  let lastFramePath = previousClip?.lastFramePath;

  // If previous clip exists but last frame was never extracted, extract it now
  if (previousClip?.videoPath && !lastFramePath) {
    try {
      lastFramePath = await extractLastFrame(
        previousClip.videoPath,
        path.join(
          path.dirname(previousClip.videoPath),
          `${previousClip.id}_lastframe.jpg`
        )
      );
    } catch (err) {
      console.warn("Could not extract last frame:", err);
    }
  }

  const context: ContinuityContext = {
    projectId: project.id,
    previousClip: previousClip || undefined,
    lastFramePath,
    characters: project.characters,
    style: project.style,
    styleLocks: project.styleLocks,
    userScript: request.script,
  };

  // Build the final prompt with heavy continuity language
  const { finalPrompt, negativePrompt } = buildPromptFromTemplate(
    context,
    request
  );

  // Collect all face / identity reference images
  const referenceImagePaths = collectReferenceImages(project, request);

  // Decide best provider for this generation
  const recommendedProvider = chooseProvider(project, request, !!lastFramePath);

  const generationParams: Record<string, any> = {
    duration: request.duration ?? 15,
    aspect_ratio: project.styleLocks?.aspectRatio ?? "16:9",
    // Strength of image conditioning – higher when we have last frame + faces
    reference_strength: lastFramePath ? 0.75 : 0.55,
    face_lock_strength: request.strengthenFaceLock ? 0.9 : 0.75,
  };

  // If we have a last frame, many providers accept it as "start image" or "extend"
  if (lastFramePath) {
    generationParams.start_image = lastFramePath;
    generationParams.mode = "extend"; // or "continue" depending on provider
  }

  return {
    context,
    finalPrompt,
    negativePrompt,
    referenceImagePaths,
    lastFramePath,
    recommendedProvider,
    generationParams,
  };
}

/**
 * Get the last approved clip (the foundation for the next one)
 */
export function getLastApprovedClip(project: Project): Clip | null {
  if (!project.lastApprovedClipId) {
    // Fallback: find highest index approved clip
    const approved = project.clips
      .filter((c) => c.status === "approved")
      .sort((a, b) => b.index - a.index);
    return approved[0] || null;
  }
  return (
    project.clips.find((c) => c.id === project.lastApprovedClipId) || null
  );
}

/**
 * Collect every face and identity image that should be sent to the model.
 * Multiple angles dramatically improve face lock.
 */
function collectReferenceImages(
  project: Project,
  request: GenerationRequest
): string[] {
  const paths: string[] = [];

  for (const character of project.characters) {
    // Face references first (most important)
    for (const assetId of character.faceReferences) {
      const asset = project.assets.find((a) => a.id === assetId);
      if (asset?.path) paths.push(asset.path);
    }
    // Full body if available
    if (character.fullBodyReferences) {
      for (const assetId of character.fullBodyReferences) {
        const asset = project.assets.find((a) => a.id === assetId);
        if (asset?.path) paths.push(asset.path);
      }
    }
  }

  // Also include any logo / product if the style is an ad
  if (project.style === "realistic_ad") {
    const logos = project.assets.filter((a) => a.type === "logo" || a.type === "product");
    for (const logo of logos) {
      if (logo.path) paths.push(logo.path);
    }
  }

  // Deduplicate
  return [...new Set(paths)];
}

/**
 * Choose the best provider based on current needs.
 * Priority order is tuned for continuity + face lock quality (2026 landscape).
 */
function chooseProvider(
  project: Project,
  request: GenerationRequest,
  hasLastFrame: boolean
): string {
  if (request.provider) return request.provider;

  // Talking head / strong face lock needed → prefer HeyGen or models strong at identity
  const needsStrongFace =
    request.strengthenFaceLock ||
    project.characters.some((c) => c.faceReferences.length > 0);

  if (project.style === "artist_trailer" && needsStrongFace) {
    return "heygen"; // or kling/seedance depending on talking vs cinematic
  }

  if (hasLastFrame) {
    // Native extend is best when available
    return "kling"; // Kling and Seedance currently lead on extend + identity
  }

  switch (project.style) {
    case "realistic_ad":
    case "artist_trailer":
    case "cinematic_movie":
      return "kling";
    case "music_video":
      return "seedance";
    case "anime":
    case "cartoon":
      return "seedance";
    default:
      return "kling";
  }
}

/**
 * After a clip is successfully generated, we must:
 * 1. Extract its last frame
 * 2. Mark it as the new continuity anchor when the user approves it
 */
export async function finalizeClipAfterGeneration(
  clip: Clip,
  videoPath: string
): Promise<{ lastFramePath: string }> {
  const lastFramePath = await extractLastFrame(
    videoPath,
    path.join(path.dirname(videoPath), `${clip.id}_lastframe.jpg`)
  );

  return { lastFramePath };
}

/**
 * Mark a clip as approved and make it the new continuity source.
 */
export function approveClip(project: Project, clipId: string): Project {
  const updatedClips = project.clips.map((c) => {
    if (c.id === clipId) {
      return {
        ...c,
        status: "approved" as const,
        approvedAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };
    }
    return c;
  });

  return {
    ...project,
    clips: updatedClips,
    lastApprovedClipId: clipId,
    updatedAt: new Date().toISOString(),
  };
}

/**
 * Helper: create the very first clip of a project (no previous continuity)
 */
export function createFirstClipContext(
  project: Project,
  script: string
): ContinuityContext {
  return {
    projectId: project.id,
    characters: project.characters,
    style: project.style,
    styleLocks: project.styleLocks,
    userScript: script,
  };
}
