/**
 * Continuum – Prompt Builder
 * Takes ContinuityContext + templates and produces the final high-quality prompt
 * that forces identity lock and temporal continuity.
 */

import type {
  ContinuityContext,
  GenerationRequest,
  Character,
  ProjectStyle,
} from "@/types";
import { getTemplatesForStyle, getTemplateById } from "./templates";

export interface BuiltPrompt {
  finalPrompt: string;
  negativePrompt: string;
  usedTemplateId: string;
}

/**
 * Main entry: build the final prompt for a generation request.
 */
export function buildPromptFromTemplate(
  context: ContinuityContext,
  request: GenerationRequest
): BuiltPrompt {
  const templates = getTemplatesForStyle(context.style);
  // Prefer the most specific template for the style
  const primary =
    templates.find((t) => t.style === context.style) ||
    templates.find((t) => t.id === "universal_continuity") ||
    templates[0];

  const characterLocks = buildCharacterLocks(context.characters);
  const styleLocks = buildStyleLocks(context);
  const brandLocks = ""; // can be extended later for ads
  const cameraInstruction = extractOrDefaultCamera(request.script, context.style);

  let prompt = primary.template
    .replace("{{character_locks}}", characterLocks)
    .replace("{{style_locks}}", styleLocks)
    .replace("{{brand_locks}}", brandLocks)
    .replace("{{camera_instruction}}", cameraInstruction)
    .replace("{{user_script}}", context.userScript.trim());

  // Extra continuity reinforcement when we have a previous clip
  if (context.previousClip && context.lastFramePath) {
    prompt = `CRITICAL CONTINUITY INSTRUCTION:
This is a direct continuation of the previous shot. The last frame of the previous clip is the exact starting image.
Do not change the character's face, clothing, hairstyle, age, or lighting direction.
The camera may move, but the world and people must remain the same.

${prompt}`;
  }

  // Strengthen face lock if requested
  if (request.strengthenFaceLock) {
    prompt += `\n\nFACE LOCK BOOST: Extreme identity preservation. Match the reference face with maximum accuracy. Zero drift allowed.`;
  }

  const negativePrompt = buildNegativePrompt(context.style, request.negativePrompt);

  return {
    finalPrompt: prompt.trim(),
    negativePrompt,
    usedTemplateId: primary.id,
  };
}

/**
 * Create a strong identity lock paragraph for every character.
 */
function buildCharacterLocks(characters: Character[]): string {
  if (!characters.length) {
    return "No specific character references provided. Maintain consistency with previous shot.";
  }

  return characters
    .map((char, i) => {
      const appearance = char.appearanceLock
        ? `Appearance lock: ${char.appearanceLock}`
        : "Use the exact face and features from the provided reference images.";

      return `Character ${i + 1} – "${char.name}":
- Exact face match to reference images (multiple angles provided)
- ${appearance}
- Same age, skin tone, facial structure, hair, and distinguishing features
- Natural performance, no exaggerated AI face`;
    })
    .join("\n\n");
}

function buildStyleLocks(context: ContinuityContext): string {
  const locks = context.styleLocks;
  if (!locks) {
    return getDefaultStyleLock(context.style);
  }

  const parts: string[] = [];
  if (locks.lighting) parts.push(`Lighting: ${locks.lighting}`);
  if (locks.colorGrade) parts.push(`Color grade: ${locks.colorGrade}`);
  if (locks.cameraLanguage) parts.push(`Camera language: ${locks.cameraLanguage}`);
  if (locks.aspectRatio) parts.push(`Aspect ratio: ${locks.aspectRatio}`);

  return parts.length ? parts.join("\n") : getDefaultStyleLock(context.style);
}

function getDefaultStyleLock(style: ProjectStyle): string {
  switch (style) {
    case "realistic_ad":
      return "Premium commercial lighting, clean and expensive look, controlled highlights, natural skin.";
    case "artist_trailer":
      return "Cinematic, emotional, rich contrast, motivated lighting, filmic color science.";
    case "music_video":
      return "Stylish, intentional color, fashion-aware lighting, strong visual identity.";
    case "cinematic_movie":
      return "Naturalistic film lighting, subtle contrast, realistic texture, cinematic framing.";
    case "anime":
      return "Clean anime aesthetic, consistent character design, beautiful lighting and effects.";
    case "cartoon":
      return "Appealing stylized design, consistent proportions, expressive but controlled.";
    default:
      return "High production value, consistent look across shots.";
  }
}

/**
 * Try to pull a camera instruction from the user script, otherwise give a smart default.
 */
function extractOrDefaultCamera(script: string, style: ProjectStyle): string {
  const lower = script.toLowerCase();
  const cameraKeywords = [
    "dolly",
    "tracking",
    "crane",
    "orbit",
    "push-in",
    "pull back",
    "handheld",
    "static",
    "low angle",
    "high angle",
    "close-up",
    "wide shot",
    "medium shot",
    "over the shoulder",
    "pov",
  ];

  for (const kw of cameraKeywords) {
    if (lower.includes(kw)) {
      return `Follow the camera direction described in the script: ${script}`;
    }
  }

  // Smart defaults per style
  switch (style) {
    case "artist_trailer":
      return "Slow, confident push-in or elegant lateral move. Keep the face readable for emotional impact.";
    case "realistic_ad":
      return "Smooth, premium camera move – gentle push-in or controlled orbit. Product and face stay sharp.";
    case "music_video":
      return "Rhythmic but controlled camera. Match the energy of the section without becoming chaotic.";
    case "cinematic_movie":
      return "Motivated, invisible camera movement. Support the performance, never distract.";
    default:
      return "Cinematic, purposeful camera movement. Prefer smooth moves over static unless tension is needed.";
  }
}

function buildNegativePrompt(
  style: ProjectStyle,
  extra?: string
): string {
  const base = [
    "identity drift",
    "face morphing",
    "different person",
    "changed face",
    "beautified beyond recognition",
    "plastic skin",
    "over-smoothed face",
    "extra limbs",
    "deformed hands",
    "warped face",
    "inconsistent lighting",
    "sudden wardrobe change",
    "jump cut",
    "scene reset",
    "low quality",
    "blurry",
    "watermark",
    "text overlay",
    "logo distortion",
  ];

  if (style === "anime" || style === "cartoon") {
    base.push("photorealistic", "live action", "real human skin");
  } else {
    base.push("anime", "cartoon", "illustration", "3d render look");
  }

  if (extra) base.push(extra);

  return base.join(", ");
}

/**
 * Utility for the UI: return suggested camera moves for a style.
 */
export function getSuggestedCameraMoves(style: ProjectStyle): string[] {
  const templates = getTemplatesForStyle(style);
  const specific = templates.find((t) => t.style === style);
  return specific?.suggestedCameraMoves || [
    "slow push-in",
    "gentle tracking shot",
    "elegant orbit",
    "low angle",
    "intimate close-up",
  ];
}
