/**
 * Continuum – Prompt Template Library
 * High-quality, production-oriented templates with strong continuity language.
 */

import type { PromptTemplate, ProjectStyle } from "@/types";

export const PROMPT_TEMPLATES: PromptTemplate[] = [
  // ─────────────────────────────────────────────
  // UNIVERSAL CONTINUITY BASE
  // ─────────────────────────────────────────────
  {
    id: "universal_continuity",
    name: "Universal Continuity Injector",
    style: "universal",
    description: "Core language that forces the model to continue from previous shot",
    template: `Continue the exact same scene and characters from the previous shot without any reset or jump cut.

IDENTITY LOCK (CRITICAL):
{{character_locks}}

STYLE & LOOK LOCK:
{{style_locks}}

CAMERA & MOTION:
{{camera_instruction}}

SCENE ACTION (this 12-16 second segment):
{{user_script}}

Technical requirements:
- Photorealistic skin texture, natural micro-expressions, correct eye reflections
- Consistent lighting direction and intensity with previous shot
- No face morphing, no identity drift, no sudden wardrobe change
- Smooth temporal continuity – the last frame of previous clip is the starting point
- Cinematic color science, high dynamic range, filmic motion blur where appropriate`,
  },

  // ─────────────────────────────────────────────
  // REALISTIC AD
  // ─────────────────────────────────────────────
  {
    id: "realistic_ad_product",
    name: "Realistic Product Advertisement",
    style: "realistic_ad",
    description: "High-end commercial look with product and logo emphasis",
    template: `High-end commercial advertisement, photorealistic, shot on ARRI Alexa or equivalent.

Continue seamlessly from previous shot.

IDENTITY & BRAND LOCK:
{{character_locks}}
{{brand_locks}}

LIGHTING: Soft, premium, controlled studio or golden-hour practical lighting. Consistent with previous shot.

CAMERA: {{camera_instruction}}

THIS SEGMENT:
{{user_script}}

Requirements:
- Product and logo must remain sharp, correctly proportioned, and brand-accurate
- Hands and product interaction must look natural and intentional
- Shallow depth of field when appropriate, beautiful bokeh
- Ultra-clean, expensive commercial finish
- 24fps cinematic motion`,
    suggestedCameraMoves: [
      "slow push-in on product",
      "elegant orbit around subject",
      "smooth tracking shot following the product",
      "low angle heroic reveal",
      "macro detail insert then pull back",
    ],
  },

  // ─────────────────────────────────────────────
  // ARTIST TRAILER
  // ─────────────────────────────────────────────
  {
    id: "artist_trailer",
    name: "Artist Promo / Movie-Style Trailer",
    style: "artist_trailer",
    description: "Cinematic trailer energy with voice-over friendly pacing and face lock",
    template: `Cinematic artist promotional trailer, high production value, emotional and powerful.

Continue directly from the previous shot. Same person, same lighting, same environment energy.

FACE & IDENTITY LOCK (NON-NEGOTIABLE):
{{character_locks}}
The face must be an exact match to the provided reference images. No beautification that changes identity. Natural skin, real pores, real asymmetries.

THIS 12-16 SECOND BEAT:
{{user_script}}

CAMERA LANGUAGE: {{camera_instruction}}

STYLE:
- Moody, cinematic color grade with rich contrast
- Motivated lighting (practicals, window light, or dramatic side light)
- Shallow depth of field on emotional close-ups
- Occasional slow-motion (40-60fps feel) on key emotional moments
- Trailer pacing: purposeful, not rushed

Audio note for later: This segment should leave space for voice-over. Visuals should not be overly busy during spoken lines.`,
    suggestedCameraMoves: [
      "slow dramatic push-in on face",
      "profile to front turn",
      "low angle confident walk",
      "handheld intimate close-up",
      "crane up revealing environment",
      "quick cut-friendly medium shot",
    ],
    hasVoiceOver: true,
  },

  // ─────────────────────────────────────────────
  // MUSIC VIDEO
  // ─────────────────────────────────────────────
  {
    id: "music_video",
    name: "Music Video",
    style: "music_video",
    description: "Rhythm-aware, stylish, performance + narrative hybrid",
    template: `High-quality music video, stylish and rhythm-driven.

Continue from previous shot with the same artist and visual world.

IDENTITY LOCK:
{{character_locks}}

THIS SEGMENT (sync with music energy):
{{user_script}}

CAMERA: {{camera_instruction}}

Visual rules:
- Strong sense of rhythm and timing even in a single continuous take
- Fashion-aware lighting and wardrobe consistency
- Dynamic but controlled camera – never shaky unless intentional
- Can mix performance energy with narrative/story moments
- Color grade should feel intentional and album-art coherent`,
    suggestedCameraMoves: [
      "rhythmic push and pull",
      "circular orbit around artist",
      "tracking alongside performance",
      "whip pan energy transition",
      "slow-motion drop on beat",
      "low angle power stance",
    ],
  },

  // ─────────────────────────────────────────────
  // CINEMATIC MOVIE
  // ─────────────────────────────────────────────
  {
    id: "cinematic_movie",
    name: "Cinematic Movie Scene",
    style: "cinematic_movie",
    description: "Narrative film language with multi-shot potential and strong continuity",
    template: `Cinematic narrative film scene, shot as if for a major motion picture.

Seamless continuation from previous shot. No reset.

CHARACTER IDENTITY:
{{character_locks}}

SCENE:
{{user_script}}

CAMERA: {{camera_instruction}}

Cinematography rules:
- Motivated camera movement only
- Lighting continuity with previous shot is mandatory
- Naturalistic performance, subtle acting
- Film grain and texture appropriate to the intended look
- Aspect ratio and lens language consistent with the project`,
    suggestedCameraMoves: [
      "motivated dolly in",
      "over-the-shoulder coverage",
      "slow lateral tracking",
      "crane revealing new information",
      "static locked-off for tension",
      "following shot with natural lag",
    ],
  },

  // ─────────────────────────────────────────────
  // ANIME / CARTOON
  // ─────────────────────────────────────────────
  {
    id: "anime",
    name: "Anime Style",
    style: "anime",
    description: "High-quality anime with consistent character design",
    template: `High-quality anime, consistent character design, expressive and cinematic.

Continue the exact same characters and scene from previous frame.

CHARACTER DESIGN LOCK:
{{character_locks}}

THIS SEGMENT:
{{user_script}}

CAMERA: {{camera_instruction}}

Anime requirements:
- Consistent eye shape, hair, proportions across shots
- Clean line work, beautiful lighting (rim light, ambient occlusion)
- Dynamic but readable action
- Emotional expression range while keeping identity stable`,
    suggestedCameraMoves: [
      "dramatic low angle",
      "speed-line enhanced tracking",
      "impact frame style push",
      "soft focus emotional close-up",
      "establishing to intimate cut",
    ],
  },
  {
    id: "cartoon",
    name: "Cartoon / Stylized 2D-3D",
    style: "cartoon",
    description: "Stylized cartoon with strong character consistency",
    template: `High-quality stylized cartoon (2D or 3D hybrid feel), consistent character design.

Continue seamlessly.

CHARACTER LOCK:
{{character_locks}}

ACTION:
{{user_script}}

CAMERA: {{camera_instruction}}

Style notes: Clean shapes, appealing design language, expressive timing, consistent proportions.`,
    suggestedCameraMoves: [
      "bouncy tracking",
      "exaggerated perspective push",
      "fun orbit",
      "slam-zoom for comedy or impact",
    ],
  },
];

export function getTemplatesForStyle(style: ProjectStyle): PromptTemplate[] {
  return PROMPT_TEMPLATES.filter(
    (t) => t.style === style || t.style === "universal"
  );
}

export function getTemplateById(id: string): PromptTemplate | undefined {
  return PROMPT_TEMPLATES.find((t) => t.id === id);
}
