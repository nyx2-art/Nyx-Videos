/**
 * Continuum – Core Type System
 * Focused on continuity, identity lock, and multi-modal assets.
 */

export type ProjectStyle =
  | "realistic_ad"
  | "artist_trailer"
  | "music_video"
  | "cinematic_movie"
  | "cartoon"
  | "anime";

export type ClipStatus =
  | "pending"
  | "generating"
  | "ready"
  | "approved"
  | "rejected"
  | "failed";

export type AssetType =
  | "face_reference"
  | "full_body_reference"
  | "logo"
  | "product"
  | "style_reference"
  | "voice_sample"
  | "song"
  | "sfx"
  | "music"
  | "video_reference";

export type GenerationProvider =
  | "kling"
  | "seedance"
  | "veo"
  | "runway"
  | "heygen"
  | "luma";

export interface Character {
  id: string;
  projectId: string;
  name: string;
  /** Primary face references – multiple angles strongly recommended */
  faceReferences: string[]; // asset IDs
  fullBodyReferences?: string[];
  /** Voice clone ID from the voice provider (ElevenLabs etc.) */
  voiceCloneId?: string;
  /** Optional description lock for consistency */
  appearanceLock?: string;
  createdAt: string;
  updatedAt: string;
}

export interface Asset {
  id: string;
  projectId: string;
  type: AssetType;
  filename: string;
  path: string; // relative or absolute storage path
  mimeType: string;
  size: number;
  /** For voice samples: duration in seconds */
  duration?: number;
  /** For face refs: optional metadata (angle, expression) */
  meta?: Record<string, any>;
  createdAt: string;
}

export interface Clip {
  id: string;
  projectId: string;
  /** Order in the project timeline (0-based) */
  index: number;
  /** The 10–20s script / prompt for this segment */
  script: string;
  /** Final generated prompt after template + continuity injection */
  finalPrompt?: string;
  /** Path to the generated video file */
  videoPath?: string;
  /** Path to the last frame extracted from this clip (for next continuity) */
  lastFramePath?: string;
  status: ClipStatus;
  /** Which provider was used */
  provider?: GenerationProvider;
  /** Generation parameters used */
  generationParams?: Record<string, any>;
  /** Duration of the clip in seconds */
  duration?: number;
  /** Error message if failed */
  error?: string;
  /** Linked character IDs used in this clip */
  characterIds?: string[];
  createdAt: string;
  updatedAt: string;
  approvedAt?: string;
}

export interface Project {
  id: string;
  name: string;
  style: ProjectStyle;
  description?: string;
  /** All characters belonging to this project */
  characters: Character[];
  /** All uploaded assets */
  assets: Asset[];
  /** Ordered list of clips */
  clips: Clip[];
  /** Currently active / last approved clip ID (for continuity) */
  lastApprovedClipId?: string;
  /** Global style locks that get injected into every prompt */
  styleLocks?: {
    lighting?: string;
    colorGrade?: string;
    cameraLanguage?: string;
    aspectRatio?: "16:9" | "9:16" | "1:1" | "2.39:1";
  };
  /** For music video mode */
  songAssetId?: string;
  createdAt: string;
  updatedAt: string;
}

export interface ContinuityContext {
  projectId: string;
  previousClip?: Clip;
  lastFramePath?: string;
  characters: Character[];
  style: ProjectStyle;
  styleLocks?: Project["styleLocks"];
  /** Extra user instructions for this segment */
  userScript: string;
}

export interface PromptTemplate {
  id: string;
  name: string;
  style: ProjectStyle | "universal";
  description: string;
  /** The base template string with {{placeholders}} */
  template: string;
  /** Recommended camera moves for this template */
  suggestedCameraMoves?: string[];
  /** Whether this template expects voice-over */
  hasVoiceOver?: boolean;
}

export interface GenerationRequest {
  projectId: string;
  clipId: string;
  script: string;
  /** Override provider */
  provider?: GenerationProvider;
  /** Force stronger face lock */
  strengthenFaceLock?: boolean;
  /** Desired duration in seconds (approx 10-20) */
  duration?: number;
  /** Extra negative prompt */
  negativePrompt?: string;
}

export interface GenerationResult {
  success: boolean;
  videoPath?: string;
  lastFramePath?: string;
  duration?: number;
  provider?: GenerationProvider;
  error?: string;
  rawResponse?: any;
}

export interface VoiceCloneRequest {
  projectId: string;
  characterId: string;
  sampleAssetIds: string[]; // one or more voice sample assets
  name?: string;
}

export interface MusicVideoRequest {
  projectId: string;
  songAssetId: string;
  /** Optional structure hints */
  structureHints?: string;
}
